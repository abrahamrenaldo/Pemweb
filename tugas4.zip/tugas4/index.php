<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elemen Form</title>
</head>
<body>
    <h3>Pendaftaran Online<h3>
    <form method="POST" action="konfirmasi.php">
        <table rules="rows">
        <tr>
                <td>Jalur Penerimaan Mahasiswa Baru</td>
                <td><select name="Pilih_Jalur" id=""style="width:100%;">
                    <option value="">Pilih Jalur Penerimaan</option>
                    <option value="2015">Jalur Reguler</option>
                    <option value="2016">Jalur Bidikmisi</option> 
                    <option value="2017">Jalur Beasiswa Peringkat Rapot</option>
                    <option value="2018">Jalur Beasiswa Ujian Saringan Masuk</option>
                </select></td>
            </tr>
            <tr>
                <td>Nama Calon Mahasiswa</td>
                <td><input type="text" name="name" placeholder="Masukan nama..." style="width:99%;"></td>
            </tr>
            <tr>
                <td>Tempat Lahir</td>
                <td><input type="text" name="TempatLahir" placeholder= "Tempat Lahir"style="width:99%;"></td>
            </tr>
            <tr>
                <td> Tanggal Lahir</td>
                <td><input type="date" name="Tgllahir"style="width:99%;"></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td><input type="radio" name="JK" Value="Laki-Laki">Laki-laki
                <input type="radio" name="JK" Value="Perempuan">Perempuan</td>
            </tr>
            <tr>
                <td>Agama</td>
                <td><select name="Agama" id=""style="width:100%;">
                    <option value="">--pilih--</option>
                    <option value="Islam">Islam</option>
                    <option value="Kristen">Kristen</option> 
                    <option value="Hindu">Hindu</option>
                    <option value="Budha">Budha</option>
                    <option value="Katolik">Katolik</option>
                    <option value="Lainnya">Lainnya</option>
                </select></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><input type="text" name="Alamat" placeholder="" style="width:99%;"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" name="Email" placeholder="" style="width:99%;"></td>
            </tr>

        </table>
        <br>
        <td><button type="submit" name="submit" value="submit">Kirim</button></td>
    </form>
</body>
</html>