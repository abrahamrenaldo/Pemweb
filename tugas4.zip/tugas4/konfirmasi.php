<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>di konfirmasi
    <table border="1">
        <tr>
            <td>Jalur Penerimaan Mahasiswa Baru</td>
            <td>:</td>
            <td><?php echo $_POST['Pilih_Jalur']; ?></td>
        </tr>
        <tr>
            <td>Nama Calon Mahasiswa</td>
            <td>:</td>
            <td><?php echo $_POST['name']; ?></td>
        </tr>
        <tr>
            <td>Tempat Lahir</td>
            <td>:</td>
            <td><?php echo $_POST['TempatLahir']; ?></td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td>:</td>
            <td><?php echo $_POST['Tgllahir']; ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td><?php echo $_POST['JK']; ?></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><?php echo $_POST['Agama']; ?></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><?php echo $_POST['Alamat']; ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td><?php echo $_POST['Email']; ?></td>
        </tr>
    </table>
</body>
</html>